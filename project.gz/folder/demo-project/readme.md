# starting API 

- cd folder/demo-project/api
- export FLASK_APP=index.py
- flask run

# starting Front end 

- cd demo-project/front-end
- live-server

# Encryption
import hashlib
pass=''
(hashlib.md5(pass.encode())).hexdigest()
